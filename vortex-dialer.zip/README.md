# Vortex Dialer

A custom cold-calling dialer built for Vortexone Agency. Manages leads imported from
spreadsheets, enforces per-state calling hours, and drives a fast, distraction-free
call screen — with a pluggable telephony adapter so the phase-1 mock dialer swaps for
real Twilio calls later without touching the rest of the app.

See [`CLAUDE.md`](./CLAUDE.md) for the full architecture, lifecycle rules, and design
language.

## Structure

- `backend/` — Node.js + Express API, PostgreSQL, JWT auth, mock/Twilio telephony adapter
- `frontend/` — React + Vite + Tailwind CSS, neumorphic design system

## Quickstart

```bash
# backend
cd backend
cp .env.example .env
npm install
npm run migrate
npm run seed
npm run dev

# frontend (separate terminal)
cd frontend
npm install
npm run dev
```

Default dev login is created by the seed script — see `backend/src/db/seeds/` output.
